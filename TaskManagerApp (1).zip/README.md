# TaskManagerApp

A simple Java console application that allows users to manage a list of tasks using object-oriented programming.

## Features

- Add a task
- List all tasks
- Mark a task as completed
- Remove a task

## How to Run

1. Open a terminal and navigate to the `src` folder.
2. Compile all Java files:

```bash
javac Main.java TaskManager.java Task.java
```

3. Run the app:

```bash
java Main
```
